# Entrega N1 Tobias Abalos Bertoldi
base_de_datos = {}

def regist_user():
     usuario = input('Ingrese usuario: ')
     contraseña = input('Ingrese contraseña: ')       
     if usuario == contraseña:
         print('Escriba una contraseña diferente al usuario, presione 1 para reintentarlo.')
     else:
         base_de_datos[usuario] = contraseña
         print('Usuario registrado.')

def mostrar_users():
     print('Informacion de registros: ')
     for usuario, contraseña in base_de_datos.items():
         print(f'Usuario: {usuario}, contraseña: {contraseña}')
     if not base_de_datos:
         print('No existen registros.')
     datos = str(len(base_de_datos))
     print('Cantidad de registros: ', datos)
         
def login():
    usuario = input('Ingrese su usuario: ')
    if usuario in base_de_datos:
        contraseña = input('Ingrese su contraseña: ')
        if base_de_datos[usuario] == contraseña:
            print(f'Bienvenido, {usuario}.')
        else:
            print('Contraseña incorrecta.')
    else:
        print('Usuario no registrado.')
        
def menu():
    while True:
        print('''Seleccionar una opcion:
              1. Registrar usuario
              2. Mostrar informacion
              3. Login
              4. Salir''')
        opcion = input('Seleccione una opcion: ')
        if opcion == '1':
            regist_user()
        elif opcion == '2':
            mostrar_users()
        elif opcion == '3':
            login()
        elif opcion == '4':
            break
        else:
            print('Opcion no valida. Ingrese una opcion valida.')
            
menu()
        
         
         

    

