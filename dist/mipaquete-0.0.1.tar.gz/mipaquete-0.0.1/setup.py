from setuptools import setup

setup(
    author='Jorge',
    author_email='jorgeasd@awa.com',
    description='Prueba de creacion de paquete redistrubuible',
    version='0.0.1',
    name='mipaquete',
    packages=['paquete']
)